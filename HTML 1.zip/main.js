document.getElementById("formKontak").addEventListener("submit", function(e) {
  e.preventDefault();
  
  const nama = document.getElementById("nama").value;
  const email = document.getElementById("email").value;
  const pesan = document.getElementById("pesan").value;

  if (nama && email && pesan) {
    document.getElementById("respon").textContent = `Terima kasih, ${nama}! Pesan Anda telah dikirim.`;
    document.getElementById("formKontak").reset();
  } else {
    document.getElementById("respon").textContent = "Harap lengkapi semua kolom.";
  }
});
